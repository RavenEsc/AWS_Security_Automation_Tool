# This file is protected via CODEOWNERS
from __future__ import annotations

__version__ = "2.0.4"
